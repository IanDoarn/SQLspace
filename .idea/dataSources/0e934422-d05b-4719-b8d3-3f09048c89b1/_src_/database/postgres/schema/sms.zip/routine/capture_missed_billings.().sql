CREATE FUNCTION capture_missed_billings () RETURNS integer
	LANGUAGE plpgsql
AS $$

DECLARE
  rowcount integer := 0;
  total_count integer := 0;
  snapshot_date date;
  
BEGIN

  snapshot_date := current_date - 30;

  insert into sms.billing
  with invoices as (
    select
      ih.invoice_dte, ih.invoice_nbr, ih.sales_order_id, ih.shipping_sales_territory_id as terr, 
      ih.invc_net_amt, ih.invc_freight_amt, ih.cust_purchase_order_cde as po,
      cast ((regexp_matches (ih.cust_purchase_order_cde, 'CASE (\d+)'))[1] as bigint) as case_Id,
      cast ((regexp_matches (ih.cust_purchase_order_cde, 'MVMT (\d+)'))[1] as bigint) as movement_id,
      ih.create_user_id
    from dcs.invoice_header ih
    where
      ih.invoice_dte >= snapshot_date and
      ih.sales_office_cde = '01' and
      ih.sales_order_type_cde = '6' and
      ih.transfer_order_type_cde = '6' and
      ih.cust_purchase_order_cde ~ '^CASE \d+ MVMT \d+'
  )
  select
    ci.order_id, i.movement_id, ci.payback_order, ci.shipping_cost, coalesce (-ci.days_before_due, 0),
    ci.recommended_late_fee, i.invc_net_amt - i.invc_freight_amt as late_fee, i.invoice_dte,
    i.create_user_id, i.sales_order_id, i.invoice_nbr,
    i.invoice_dte, i.create_user_id, i.sales_order_id, i.invoice_nbr,
    'Manually added ' || current_timestamp
  from
    invoices i
    join sms.ci_order_movement_summary ci on
      i.movement_id = ci.movement_number and
      i.case_id = ci.case_number
  where
    not exists (
      select null
      from sms.billing b
      where
        b.movement_number = i.movement_id
    );

  
  GET DIAGNOSTICS rowcount = ROW_COUNT;
  total_count := total_count + rowcount;

  return total_count;
END;
$$
