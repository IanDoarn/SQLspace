CREATE TRIGGER insert_movement_trigger
BEFORE INSERT ON sms.movement
FOR EACH ROW EXECUTE PROCEDURE sms.movement_insert_trigger()