CREATE FUNCTION update_lp_products () RETURNS void
	LANGUAGE plpgsql
AS $$

begin
  -- insert parts that don't exist

  insert into sms.lp_products
  select
    b.product_number, current_date, null, true
  from
    sms.lp_stock_levels b
  where not exists (
    select null
    from sms.lp_products c
    where
      b.product_number = c.product_number
  );

  -- flag parts that are not there any more

  update sms.lp_products
  set
    remove_date = current_date,
    active_flag = false
  where product_number not in (select product_number from sms.lp_stock_levels);

  -- flag reactivated parts as active

  update sms.lp_products
  set
    active_flag = true
  from
    sms.lp_stock_levels b
  where
    sms.lp_products.product_number = b.product_number and
    active_flag = false;

end;
$$
