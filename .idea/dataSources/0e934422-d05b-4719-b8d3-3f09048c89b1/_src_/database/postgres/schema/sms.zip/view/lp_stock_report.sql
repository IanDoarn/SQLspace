CREATE VIEW lp_stock_report AS
SELECT (((d.territory)::text || ' - '::text) || (d.name)::text) AS distributor,
    lt.description AS location_type,
    p.product_number,
    p.description,
    s.quantity_on_hand AS qoh,
        CASE
            WHEN (s.hold_reason = 0) THEN 'No'::text
            ELSE 'Yes'::text
        END AS on_hold,
    h.description AS hold_reason,
    s.hold_note,
    e.description AS inventory_type,
    f.serial_number AS lot_serial,
    f.expiration_date,
    f.expires,
    d.territory,
    p.edi_number,
    s.lot_id,
        CASE
            WHEN (s.container_id = 0) THEN NULL::text
            ELSE (((ct.description)::text || '-'::text) || s.container_id)
        END AS contained_by,
    p.id AS product_id
   FROM (((((((sms.stock s
     LEFT JOIN sms.enum lt ON (((s.location_type = lt.enum_id) AND ((lt.entity_name)::text = 'location_type'::text))))
     LEFT JOIN sms.enum ct ON (((s.container_type = ct.enum_id) AND ((ct.entity_name)::text = 'container_type'::text))))
     JOIN sms.product p ON ((s.product_id = p.id)))
     JOIN sms.distributor d ON ((s.distributor_id = d.id)))
     LEFT JOIN sms.enum e ON (((s.inventory_type = e.enum_id) AND ((e.entity_name)::text = 'inventory_type'::text))))
     LEFT JOIN sms.product_serial f ON ((s.serial_id = f.id)))
     LEFT JOIN sms.enum h ON (((s.hold_reason = h.enum_id) AND ((h.entity_name)::text = 'hold_reason'::text))))
  WHERE (s.inventory_type = ANY (ARRAY[2, 3]))