CREATE FUNCTION build_ci_inventory_summary () RETURNS integer
	LANGUAGE plpgsql
AS $$

DECLARE
  rowcount integer := 0;
  totalrow integer := 0;
BEGIN

  truncate table sms.ci_inventory;

  insert into sms.ci_inventory
  select
    case
      when p.business_unit_id = 0 and p.is_biomet = 0 then p.edi_number
      else p.product_number
    end,
    s.id as stock_id, s.quantity_on_hand, s.quantity_available,
    s.quantity_reserved, s.quantity_short, s.lot_id,
    b.zone || '-' || b.position || '-' || b.shelf AS bin
  FROM
    sms.stock s
    join sms.product p on s.product_id = p.id
    left JOIN sms.bin b ON s.container_id=b.id AND s.container_type = 1
  WHERE
    s.location_id in (370, 1871) and
    s.location_type = 1 and
   (b.zone not like 'Vehicle%' or b.zone is null) and
    case
      when p.business_unit_id = 0 and p.is_biomet = 0 then p.edi_number
      else p.product_number
    end is not null;

  GET DIAGNOSTICS rowcount = ROW_COUNT;
  totalrow = totalrow + rowcount;

  truncate table sms.ci_inventory_summary;

  insert into sms.ci_inventory_summary
  select
    ci.prod_id, sum (quantity_available)
  from
    sms.ci_inventory ci
  group by
    ci.prod_id;

  GET DIAGNOSTICS rowcount = ROW_COUNT;
  totalrow = totalrow + rowcount;

  return totalrow;
END;
$$
