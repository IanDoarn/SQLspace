CREATE FUNCTION millstone_stock_history_insert_trigger () RETURNS trigger
	LANGUAGE plpgsql
AS $$

BEGIN
  if (new.active_flag != 'I') then
    insert into table_partitions.millstone_stock_history_current values (new.*);
  elsif (new.eff_thru >= '2015-01-01' and new.eff_thru < '2016-01-01') then
    insert into table_partitions.millstone_stock_history_2015 values (new.*);
  elsif (new.eff_thru >= '2016-01-01' and new.eff_thru < '2017-01-01') then
    insert into table_partitions.millstone_stock_history_2016 values (new.*);
  elsif (new.eff_thru >= '2017-01-01' and new.eff_thru < '2018-01-01') then
    insert into table_partitions.millstone_stock_history_2017 values (new.*);
  elsif (new.eff_thru >= '2018-01-01' and new.eff_thru < '2019-01-01') then
    insert into table_partitions.millstone_stock_history_2018 values (new.*);
  end if;
  return null;
END;
$$
