CREATE FUNCTION generate_ci_inbound_outbound () RETURNS integer
	LANGUAGE plpgsql
AS $$

DECLARE
  rowcount integer := 0;
  total_count integer := 0;
  todays_date integer := 0;
  fresh_start_date integer := 0;
  max_days_late integer := 0;
  lp_date date;
  
BEGIN

  update sms.ci_shipments_out_raw r
  set
    shipping_weight = fo.weight
  from
    sms.freight_override fo
  where
    r.package_id = fo.package_id and
    fo.weight is not null and
    fo.weight != r.shipping_weight;

  -- Query returned successfully: 128134 rows affected, 311275 ms execution time.
  -- Query returned successfully: 302821 rows affected, 850087 ms execution time.  7/29/2014
  -- Query returned successfully: 302650 rows affected, 295180 ms execution time.  7/29/2014, after temp tables
  -- Query returned successfully: 816559 rows affected, 15418 ms execution time. 10/28/14, move sms.ci_shipments_out_raw to Oracle
  -- Query returned successfully: 947044 rows affected, 19391 ms execution time. 11/20/14

  truncate table sms.ci_shipments_out;

  insert into sms.ci_shipments_out
  select
    ci.distributor_id, ci.case_number, ci.surgery_date, ci.account_id, ci.surgeon_id, 
    min (ci.movement_number), min (ci.sourced_date), max (ci.pick_date),
    max (ci.pick_user_id), min (ci.shipped_date), 
    max (ci.closed_date), min (ci.tracking_number), ci.package_status,
    ci.product_id, min (ci.lot_number), sum (ci.quantity_picked),
    ci.imp_payback_order, ci.ins_payback_order,
    sum (case when ci.tracking_rn = 1 then ci.shipping_weight else 0 end), 
    ci.order_id, sum (ci.quantity_requested), sum (ci.quantity_open),
    sum (ci.quantity_reserved), sum (ci.quantity_fulfilled), 
    ci.shipping_service_id, sum (ci.adjustment_qty), ci.header_record,
    case
      when ci.tracking_rn != 0 then 0
      when fx.weight is null then 0
      when fx.weight = 0 then 0
      when min (ci.shipped_date) < '2013-10-03'::date then 0  -- Per Andrea
      when min (fo.freight) is not null then min (fo.freight)
      when coalesce (fo.ship_via, so.ship_via, ss.dcs_code) = '11' then fx.priority_11
      when coalesce (fo.ship_via, so.ship_via, ss.dcs_code) = '14' then fx.standard_14
      when coalesce (fo.ship_via, so.ship_via, ss.dcs_code) = '10' then fx.economy_10
      when coalesce (fo.ship_via, so.ship_via, ss.dcs_code) = '51' then fx.saturday_del_51
      when coalesce (fo.ship_via, so.ship_via, ss.dcs_code) = '19' then fx.ground_19
      when coalesce (fo.ship_via, so.ship_via, ss.dcs_code) = '32' then fx.first_overnight_32
      when coalesce (fo.ship_via, so.ship_via, ss.dcs_code) = '23' then fx.ups_red_label_23
      else 0
    end as freight_charge,
    coalesce (fo.ship_via, so.ship_via, ss.dcs_code) as ship_via,
    ci.pull_by_date, ci.ship_by_date, ci.deliver_by_date,
    sum (case when ci.tracking_rn = 0 then ci.shipping_cost else 0 end) as shipping_cost
  from
    sms.ci_shipments_out_raw ci
    left join sms.shipping_service ss on
      ci.shipping_service_id = ss.id
    left join sms.shipping_service_override so on
      ci.shipping_service_id = so.id
    left join sms.freight_override fo on
      ci.package_id = fo.package_id
    left join sms.fedex_rates fx on
      ceiling (ci.shipping_weight) = fx.weight
  group by
    ci.distributor_id, ci.case_number, ci.surgery_date, ci.account_id, ci.surgeon_id, 
    ci.package_status, ci.product_id, ci.imp_payback_order, ci.ins_payback_order,
    ci.order_id, ci.shipping_service_id, ci.header_record, fx.weight,
    fo.ship_via, so.ship_via, ss.dcs_code, ci.tracking_rn,
    ci.pull_by_date, ci.ship_by_date, ci.deliver_by_date;
    
  GET DIAGNOSTICS rowcount = ROW_COUNT;
  total_count := total_count + rowcount;

  -- Query returned successfully: 21952 rows affected, 11300 ms execution time.
  -- Query returned successfully: 38154 rows affected, 737 ms execution time.  7/29/14
  -- Query returned successfully: 121232 rows affected, 1536 ms execution time. 11/20/14

  insert into sms.ci_shipments_out
  with returnz as (
    SELECT
      parent_order_id, case_number, extension_order_number, extension_date, 
      return_due_date, product_id, quantity_requested
    FROM sms.ci_extensions_due_back
    union all
    SELECT
      parent_order_id, case_number, extension_order_number, extension_date,
      due_back, product_id, returned_quantity
    FROM sms.ci_extensions_returned
  )
  select
    c.distributor_id, r.case_number, c.surgery_date, c.account_id, c.surgeon_id,
    0 as movement_id, r.extension_date as sourced_date, null as pick_date,
    null as pick_user_id, null as shipped_date, null as closed_date,
    'Extension from order ' || parent_order_id as tracking_number, null as pack_status,
    r.product_id, null as lot_number, quantity_requested, extension_order_number,
    0, 0 as weight, 0 as order_id, quantity_requested, 0, 0, quantity_requested,
    0 as shipping_service, 0 as adj_qty, false as header_record,
    0 as freight_charge, null as ship_via, null, null, null, 0
  from
    returnz r,
    sms.case_table c
  where
    r.case_number = c.id;

  GET DIAGNOSTICS rowcount = ROW_COUNT;
  total_count := total_count + rowcount;

  select workday_index
  into todays_date
  from util.work_days
  where cal_date = current_date;

  select workday_index
  into fresh_start_date
  from util.work_days
  where cal_date = '2014-04-01';

  max_days_late := todays_date - fresh_start_date;

  truncate table sms.ci_order_line_summary;

  insert into sms.ci_order_line_summary
  with raw_returns as (
    SELECT distinct
      db.distributor_id, db.case_number, db.surgery_date, db.account_id, db.surgeon_id, 
      db.payback_order_number, db.due_date, null::bigint as movement_number,
      null::bigint as return_user_id, db.product_id, db.still_due as qty_open,
      db.paid_back as qty_returned, null::timestamp as returned_date,
      null::varchar(128) as lot_number, 0::bigint as used_qty
    FROM sms.ci_shipments_due_back db
    where (db.qty_open > 0 or db.extension_order_id is not null) and db.closed_date is null
    union all
    SELECT distinct
      sr.distributor_id, sr.case_number, sr.surgery_date, sr.account_id, sr.surgeon_id, 
      sr.payback_order_number, sr.due_back, sr.movement_number, sr.return_user_id, 
      sr.product_id, 0 as qty_open, sr.returned_quantity, sr.returned_date,
      sr.lot_number, coalesce (sr.adjustment_qty, 0)
    FROM sms.ci_shipments_returned sr
  ), returns as (
    select
      distributor_id, case_number, surgery_date, account_id, surgeon_id, payback_order_number,
      due_date, product_id, min (movement_number) as movement_number, min (return_user_id) as return_user_id,
      sum (qty_open) as qty_open, max (qty_returned) as qty_returned,
      max (returned_date) as returned_date, max (lot_number) as lot_number,
      max (used_qty) as used_qty
    from raw_returns
    group by
      distributor_id, case_number, surgery_date, account_id, surgeon_id, payback_order_number,
      due_date, product_id
  ), extensions as (
    select distinct parent_order_id, extension_order_number, extension_date, product_id
    from sms.ci_extensions_due_back
    union all
    select distinct parent_order_id, extension_order_number, extension_date, product_id
    from sms.ci_extensions_returned
  ), ci as (
    select
      so.distributor_id, so.case_number, so.surgery_date, so.account_id, 
      so.surgeon_id, so.movement_number, so.sourced_date, so.pick_date, 
      so.pick_user_id, so.shipped_date, so.closed_date, so.tracking_number, 
      so.package_status, so.product_id, so.lot_number, so.quantity_picked, 
      so.shipping_weight, so.order_id, so.shipping_service_id,
      coalesce (e1.extension_date, e2.extension_date) as extension_date,
      coalesce (e1.extension_order_number, e2.extension_order_number) as ext_order,
      coalesce (r1.payback_order_number, r2.payback_order_number) as payback_order_number,
      case
        when coalesce (r1.payback_order_number, r2.payback_order_number) = so.imp_payback_order
          then 'Implant'
        else 'Instrument'
      end as pb_order_type,
      coalesce (r1.due_date, r2.due_date) as due_date,
      coalesce (r1.movement_number, r2.movement_number) as return_movement_id,
      coalesce (r1.return_user_id, r2.return_user_id) as return_user_id,
      coalesce (r1.qty_open, r2.qty_open) as qty_open,
      coalesce (r1.qty_returned, r2.qty_returned) as qty_returned,
      coalesce (r1.returned_date, r2.returned_date) as returned_date,
      coalesce (r1.lot_number, r2.lot_number) as return_lot,
      coalesce (so.adjustment_qty, r1.used_qty, r2.used_qty) as used_qty,
      coalesce (so.header_record, false) as header_record,
      so.freight_charge, so.ship_via,
      so.pull_by_date, so.ship_by_date, so.deliver_by_date, so.shipping_cost
    from
      sms.ci_shipments_out so
      left join extensions e1 on
        so.imp_payback_order = e1.parent_order_id and
        so.product_id = e1.product_id
      left join extensions e2 on
        so.ins_payback_order = e2.parent_order_id and
        so.product_id = e2.product_id
      left join returns r1 on
        so.imp_payback_order = r1.payback_order_number and
        so.product_id = r1.product_id
      left join returns r2 on
        so.ins_payback_order = r2.payback_order_number and
        so.product_id = r2.product_id
  )
  select
    d.name as dist_name, d.territory, ci.case_number, a.name as account_name, a.account_number,
    s.code as surgeon_id, s.last_name as surgeon_name, ci.surgery_date, ci.order_id,
    ci.movement_number, ci.sourced_date, ci.pick_date, pu.username as pick_user, ci.shipped_date,
    ci.closed_date, ci.tracking_number, p.edi_number as prod_id, p.product_number, p.description,
    ci.lot_number, ci.quantity_picked as qty_out, ceiling (ci.shipping_weight), ci.ship_via,
    ci.extension_date, ci.ext_order, ci.payback_order_number, ci.due_date, ci.return_movement_id,
    ru.username as return_user, coalesce (ci.qty_open, 0) as qty_open,
    case
      when ci.ext_order is not null then ci.quantity_picked
      else coalesce (ci.qty_returned, 0)
    end as qty_returned,
    coalesce (ci.returned_date, ci.extension_date) as returned_date,
    ci.return_lot,
    coalesce (-ci.used_qty, 0) as used_qty,
    ci.freight_charge,
    case
      when ci.due_date is null then 0
      when ci.returned_date is null and ci.extension_date is null and (ci.qty_open is null or ci.qty_open = 0) then 0
      when ci.returned_date is null and ci.extension_date is null and ci.due_date::date > current_date then 0
      when ci.returned_date is null and ci.extension_date is null then
        greatest (0, least (max_days_late, w_tod.workday_index - w_due.workday_index))
      when ci.returned_date is null then
        greatest (0, least (max_days_late, w_ext.workday_index - w_due.workday_index))
      else
        greatest (0, least (max_days_late, w_ret.workday_index - w_due.workday_index))
    end as days_early_late,
    ci.header_record, w_due.workday_index - todays_date as days_before_due,
    ci.pull_by_date, ci.ship_by_date, ci.deliver_by_date, ci.shipping_cost
  from
    ci
    left join sms.account a on
      ci.account_id = a.id
    left join sms.distributor d on
      ci.distributor_id = d.id
    left join sms.surgeon s on
      ci.surgeon_id = s.id
    left join sms.product p on
      ci.product_id = p.id
    left join sms.user_table ru on
      ci.return_user_id = ru.id
    left join sms.user_table pu on
      ci.pick_user_id = pu.id
    left join util.work_days w_ret on
      ci.returned_date::date = w_ret.cal_date
    left join util.work_days w_ext on
      ci.extension_date::date = w_ext.cal_date
    left join util.work_days w_due on
      ci.due_date::date = w_due.cal_date
    join util.work_days w_tod on
      current_date = w_tod.cal_date;
      
  GET DIAGNOSTICS rowcount = ROW_COUNT;
  total_count := total_count + rowcount;

  -- Query returned successfully: 8186 rows affected, 100442 ms execution time.

  truncate table sms.ci_order_movement_summary;

  insert into sms.ci_order_movement_summary
  SELECT
    cis.dist_name,  
    cis.territory, 
    cis.case_number, 
    cis.account_name, 
    cis.account_number, 
    cis.surgeon_id, 
    cis.surgeon_name, 
    cis.surgery_date, 
    cis.order_id, 
    cis.movement_number, 
    min(cis.sourced_date) AS sourced_date, 
    max(cis.pick_date) AS pick_date, 
    max(cis.shipped_date) AS shipped_date, 
    count(cis.prod_id) AS part_count, 
    sum(cis.qty_out)::bigint AS qty_out, 
    sum(cis.shipping_weight) AS weight, 
    max(cis.ship_via::text) AS ship_via, 
    coalesce (min(cis.payback_order_number), 0) AS payback_order, 
    min(cis.due_date) AS return_due, 
    min(cis.return_movement_id) AS return_movement, 
    sum(cis.qty_open)::bigint AS qty_open, 
    sum(cis.qty_returned)::bigint AS qty_returned, 
    max(cis.returned_date) AS latest_return_date, 
    sum(cis.used_qty)::bigint AS used_qty, 
    sum(cis.freight_charge) AS freight_charge, 
    max(cis.days_early_late) AS days_late, 
    max(cis.days_before_due) AS days_before_due, 
    to_char(cis.surgery_date, 'YYYY-MM') AS surgery_month, 
    CASE
        WHEN min(cis.due_date) < '2013-10-01' THEN 0
        WHEN max(cis.days_early_late) < 4 THEN 0
        ELSE max(cis.days_early_late - 3) * bp.parameter_numeric_value
    END AS recommended_late_fee,
    max (cis.pull_by_date),
    max (cis.ship_by_date),
    max (cis.deliver_by_date),
    sum (cis.shipping_cost)
   FROM
     sms.ci_order_line_summary cis
     CROSS JOIN sms.ci_billing_parameters bp
  WHERE
    bp.parameter_name = 'DailyLateCharge' AND
    bp.effective_from <= current_date AND
    bp.effective_thru >= current_date -- AND
    -- cis.closed_date IS NULL
  GROUP BY
    cis.dist_name, cis.territory, cis.case_number, cis.account_name, cis.account_number,
    cis.surgeon_id, cis.surgeon_name, cis.surgery_date, cis.order_id, cis.movement_number,
    cis.ship_via, bp.parameter_numeric_value;

  GET DIAGNOSTICS rowcount = ROW_COUNT;
  total_count := total_count + rowcount;

  /*
    6/25/2014 -- if the return order number goes to zero and it was previously billed with
                 a return order number, change the return order number in the the billing
                 table to carry that data over
    7/24/2014 -- SMS Compliance tool changed to not key off of return order number for
                 non-extensions
  */

  /*

  update sms.billing b
  set
    return_order = 0,
    comments = 'Return Order Changed from ' || b.return_order || ' to 0 on ' || current_date
  from
    sms.ci_order_movement_summary ms
  where
    -- b.return_order = 920690 and
    b.order_number = ms.order_id and
    b.movement_number = ms.movement_number and
    b.return_order != 0 and
    b.order_number != 0 and
    b.movement_number != 0 and
    ms.payback_order = 0 and
    not exists (
      select null
      from sms.billing b2
      where
        b.order_number = b2.order_number and
        b.movement_number = b2.movement_number and
        b2.return_order = 0
    );

    */

  /*
    select * from sms.billing
    where order_number = 917194 and movement_number = 1171439

    select * from sms.ci_order_movement_summary
    where order_id = 972394 and movement_number = 1240187
  */
  
  GET DIAGNOSTICS rowcount = ROW_COUNT;
  total_count := total_count + rowcount;

  update util.table_activity
  set last_load_date = current_timestamp
  where schema_name = 'SMS'
  and table_name = upper('ci_order_line_summary');

  return total_count;
END;
$$
