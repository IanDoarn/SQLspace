CREATE FUNCTION movement_insert_trigger () RETURNS trigger
	LANGUAGE plpgsql
AS $$

BEGIN

  if (NEW.created_date >= '2020-01-01') then
    insert into table_partitions.sms_movement_2020 values (NEW.*);
  elsif (NEW.created_date >= '2019-01-01') then
    insert into table_partitions.sms_movement_2019 values (NEW.*);
  elsif (NEW.created_date >= '2018-01-01') then
    insert into table_partitions.sms_movement_2018 values (NEW.*);
  elsif (NEW.created_date >= '2017-01-01') then
    insert into table_partitions.sms_movement_2017 values (NEW.*);
  elsif (NEW.created_date >= '2016-01-01') then
    insert into table_partitions.sms_movement_2016 values (NEW.*);
  elsif (NEW.created_date >= '2015-01-01') then
    insert into table_partitions.sms_movement_2015 values (NEW.*);
  elsif (NEW.created_date >= '2014-01-01') then
    insert into table_partitions.sms_movement_2014 values (NEW.*);
  elsif (NEW.created_date >= '2013-01-01') then
    insert into table_partitions.sms_movement_2013 values (NEW.*);
  elsif (NEW.created_date >= '2012-01-01') then
    insert into table_partitions.sms_movement_2012 values (NEW.*);
  elsif (NEW.created_date >= '2011-01-01') then
    insert into table_partitions.sms_movement_2011 values (NEW.*);
  end if;
    
  RETURN NULL;
END;
$$
