CREATE VIEW territory_livelink_folders AS
SELECT ll.territory,
    ll.folder_name
   FROM reporting.territory_livelink_folders ll