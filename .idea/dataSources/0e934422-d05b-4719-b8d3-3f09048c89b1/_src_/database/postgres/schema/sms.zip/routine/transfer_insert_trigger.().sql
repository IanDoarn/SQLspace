CREATE FUNCTION transfer_insert_trigger () RETURNS trigger
	LANGUAGE plpgsql
AS $$

BEGIN
  if (NEW.created_date >= '2020-10-01') then
    insert into table_partitions.transfer_2020_q4 values (NEW.*);
  elsif (NEW.created_date >= '2020-07-01') then
    insert into table_partitions.transfer_2020_q3 values (NEW.*);
  elsif (NEW.created_date >= '2020-04-01') then
    insert into table_partitions.transfer_2020_q2 values (NEW.*);
  elsif (NEW.created_date >= '2020-01-01') then
    insert into table_partitions.transfer_2020_q1 values (NEW.*);
  elsif (NEW.created_date >= '2019-10-01') then
    insert into table_partitions.transfer_2019_q4 values (NEW.*);
  elsif (NEW.created_date >= '2019-07-01') then
    insert into table_partitions.transfer_2019_q3 values (NEW.*);
  elsif (NEW.created_date >= '2019-04-01') then
    insert into table_partitions.transfer_2019_q2 values (NEW.*);
  elsif (NEW.created_date >= '2019-01-01') then
    insert into table_partitions.transfer_2019_q1 values (NEW.*);
  elsif (NEW.created_date >= '2018-10-01') then
    insert into table_partitions.transfer_2018_q4 values (NEW.*);
  elsif (NEW.created_date >= '2018-07-01') then
    insert into table_partitions.transfer_2018_q3 values (NEW.*);
  elsif (NEW.created_date >= '2018-04-01') then
    insert into table_partitions.transfer_2018_q2 values (NEW.*);
  elsif (NEW.created_date >= '2018-01-01') then
    insert into table_partitions.transfer_2018_q1 values (NEW.*);
  elsif (NEW.created_date >= '2017-10-01') then
    insert into table_partitions.transfer_2017_q4 values (NEW.*);
  elsif (NEW.created_date >= '2017-07-01') then
    insert into table_partitions.transfer_2017_q3 values (NEW.*);
  elsif (NEW.created_date >= '2017-04-01') then
    insert into table_partitions.transfer_2017_q2 values (NEW.*);
  elsif (NEW.created_date >= '2017-01-01') then
    insert into table_partitions.transfer_2017_q1 values (NEW.*);
  elsif (NEW.created_date >= '2016-10-01') then
    insert into table_partitions.transfer_2016_q4 values (NEW.*);
  elsif (NEW.created_date >= '2016-07-01') then
    insert into table_partitions.transfer_2016_q3 values (NEW.*);
  elsif (NEW.created_date >= '2016-04-01') then
    insert into table_partitions.transfer_2016_q2 values (NEW.*);
  elsif (NEW.created_date >= '2016-01-01') then
    insert into table_partitions.transfer_2016_q1 values (NEW.*);
  elsif (NEW.created_date >= '2015-10-01') then
    insert into table_partitions.transfer_2015_q4 values (NEW.*);
  elsif (NEW.created_date >= '2015-07-01') then
    insert into table_partitions.transfer_2015_q3 values (NEW.*);
  elsif (NEW.created_date >= '2015-04-01') then
    insert into table_partitions.transfer_2015_q2 values (NEW.*);
  elsif (NEW.created_date >= '2015-01-01') then
    insert into table_partitions.transfer_2015_q1 values (NEW.*);
  elsif (NEW.created_date >= '2014-10-01') then
    insert into table_partitions.transfer_2014_q4 values (NEW.*);
  elsif (NEW.created_date >= '2014-07-01') then
    insert into table_partitions.transfer_2014_q3 values (NEW.*);
  elsif (NEW.created_date >= '2014-04-01') then
    insert into table_partitions.transfer_2014_q2 values (NEW.*);
  elsif (NEW.created_date >= '2014-01-01') then
    insert into table_partitions.transfer_2014_q1 values (NEW.*);
  elsif (NEW.created_date >= '2013-10-01') then
    insert into table_partitions.transfer_2013_q4 values (NEW.*);
  elsif (NEW.created_date >= '2013-07-01') then
    insert into table_partitions.transfer_2013_q3 values (NEW.*);
  elsif (NEW.created_date >= '2013-04-01') then
    insert into table_partitions.transfer_2013_q2 values (NEW.*);
  elsif (NEW.created_date >= '2013-01-01') then
    insert into table_partitions.transfer_2013_q1 values (NEW.*);
  elsif (NEW.created_date >= '2012-10-01') then
    insert into table_partitions.transfer_2012_q4 values (NEW.*);
  elsif (NEW.created_date >= '2012-07-01') then
    insert into table_partitions.transfer_2012_q3 values (NEW.*);
  elsif (NEW.created_date >= '2012-04-01') then
    insert into table_partitions.transfer_2012_q2 values (NEW.*);
  elsif (NEW.created_date >= '2012-01-01') then
    insert into table_partitions.transfer_2012_q1 values (NEW.*);
  else
    insert into table_partitions.transfer_2011 values (NEW.*);
  end if;
    
  RETURN NULL;
END;
$$
