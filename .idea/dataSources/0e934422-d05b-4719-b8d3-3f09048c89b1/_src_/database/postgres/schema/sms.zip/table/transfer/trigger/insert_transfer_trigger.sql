CREATE TRIGGER insert_transfer_trigger
BEFORE INSERT ON sms.transfer
FOR EACH ROW EXECUTE PROCEDURE sms.transfer_insert_trigger()