CREATE FUNCTION capture_millstone_stock_history () RETURNS integer
	LANGUAGE plpgsql
AS $$

DECLARE
  rowcount integer := 0;
  totalrow integer := 0;
BEGIN

  insert into table_partitions.millstone_stock_history_current
  SELECT
    id, distributor_id, created_date, location_type, location_id, 
    order_line_id, container_type, container_id, stock_type, product_id, 
    product_type, product_class, inventory_type, hold_id, hold_reason, 
    shortage, quantity_on_hand, quantity_available, quantity_reserved, 
    quantity_short, version, hold_note, lot_id, serial_id,
    current_date, current_date, 'C'
  FROM
    sms.millstone_stock;

  truncate table table_partitions.millstone_stock_history_stage;

  insert into table_partitions.millstone_stock_history_stage
  select
    id, distributor_id, created_date, location_type, location_id, 
    order_line_id, container_type, container_id, stock_type, product_id, 
    product_type, product_class, inventory_type, hold_id, hold_reason, 
    shortage, quantity_on_hand, quantity_available, quantity_reserved, 
    quantity_short, version, hold_note, lot_id, serial_id,
    min (eff_from), max (eff_thru),
    case
      when max (eff_thru) = current_date then 'A'
      else 'I'
    end as active_flag
  FROM
    table_partitions.millstone_stock_history_current
  group by
    id, distributor_id, created_date, location_type, location_id, 
    order_line_id, container_type, container_id, stock_type, product_id, 
    product_type, product_class, inventory_type, hold_id, hold_reason, 
    shortage, quantity_on_hand, quantity_available, quantity_reserved, 
    quantity_short, version, hold_note, lot_id, serial_id;

  truncate table table_partitions.millstone_stock_history_current;

  insert into table_partitions.millstone_stock_history_current
  select * from table_partitions.millstone_stock_history_stage
  where active_flag = 'A';

  insert into sms.millstone_stock_history
  select * from table_partitions.millstone_stock_history_stage
  where active_flag = 'I';

  truncate table table_partitions.millstone_stock_history_stage;

  GET DIAGNOSTICS rowcount = ROW_COUNT;
  totalrow = totalrow + rowcount;

  return totalrow;
END;
$$
