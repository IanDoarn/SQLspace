CREATE FUNCTION millstone_processing () RETURNS integer
	LANGUAGE plpgsql
AS $$

DECLARE
  rowcount integer := 0;
  total_count integer := 0;
  current_year integer;
  
BEGIN
  -- this is unrelated to the Centralized Inventory stuff but has the same dependency (availability
  -- of SMS tables)
  -- For Brandon Wylie, SMS shipments from Millstone

  current_year := extract (year from current_date);

  -- Query returned successfully: 18752 rows affected, 143699 ms execution time.
  -- Query returned successfully: 39056 rows affected, 188524 ms execution time.

  truncate table sms.millstone_shipments_sms;

  insert into sms.millstone_shipments_sms
  SELECT
    m.created_date AS order_date, o.id AS order_id, m.id as movement_id,
    t.id as transfer_id, p.edi_number as prod_id, p.product_number AS product_code, 
    p.description AS description, l.lot_number AS lot_id,
    t.quantity_picked AS quantity,
    case extract (year from m.created_date)
      when current_year then cs.cost_current
      when 2019 then cs.cost_2019
      when 2018 then cs.cost_2018
      when 2017 then cs.cost_2017
      when 2016 then cs.cost_2016
      when 2015 then cs.cost_2015
      when 2014 then cs.cost_2014
      when 2013 then cs.cost_2013
      when 2012 then cs.cost_2012
      when 2011 then cs.cost_2011
    end as std_cost,
    d.id as distributor_id, d.territory,
    case
      when s.country is not null then s.country
      when s2.country is not null then s2.country
      when d.territory between '01' and '95' then 'US'
      else d.country
    end,
    d.name, coalesce (s.id, s2.id) as site_id,
    case m.status
      when 1 then 'Building'
      when 2 then 'Moving'
      when 3 then 'Complete'
      when 4 then 'Cancelled'
    end as movement_status
  FROM
    sms.order_header o
    INNER JOIN sms.movement m ON
      m.order_id=o.id and
      m.id >= 825347 and
      m.created_date >= '2014-01-01'
    INNER JOIN sms.transfer t ON
      t.movement_id=m.id and
      t.id >= 7664106 and
      t.created_date > '2014-01-01'
    INNER JOIN sms.product p ON t.product_id=p.id
    INNER JOIN sms.distributor d ON m.to_distributor_id=d.id
    LEFT JOIN sms.product_lot l ON t.lot_id=l.id
    left join sms.site s on
      o.to_location_type = 1 and  -- site
      o.to_location_id = s.id
    left join sms.sales_associate sa on
      o.to_location_type = 8 and  -- sales associate
      o.to_location_id = sa.id
    left join sms.site s2 on
      sa.site_id = s2.id
    left join sms.distributor d2 on
      o.to_location_type = 2 and  -- distributor
      o.to_location_id = d2.id
    left join jde.cost_summary cs on
      p.edi_number = cs.prod_id
  WHERE
    o.id >= 669730 and
    m.from_location_type = 1 AND 
    m.from_location_id IN (470, 490, 1891) AND 
    m.status in (1, 2, 3) and  -- building, moving, completed
   (t.quantity_picked > 0 or m.status = 1);

  GET DIAGNOSTICS rowcount = ROW_COUNT;
  total_count := total_count + rowcount;

  truncate table sms.millstone_tracker;

  insert into sms.millstone_tracker
  with tracking as (
    select
      p.movement_id, p.tracking_number, min (p.status) as status,
      max (p.shipped_date) as last_shipment
    from
      sms.package p
      join sms.movement m on
        m.id = p.movement_id
    where
      m.from_location_type = 1 AND 
      m.from_location_id IN (470, 490, 1891)
    group by
      p.movement_id, p.tracking_number
  ),
  tracking2 as (
    select
      t.movement_id, min (t.status) as status,
      array (select u.tracking_number
             from tracking u
             where t.movement_id = u.movement_id
             and u.tracking_number is not null) as track_nos,
      max (t.last_shipment) as last_shipment
    from
      tracking t
    group by
      t.movement_id
  ), tracking3 as (
    select
      t.movement_id, t.status, t.track_nos, t.last_shipment,
      e.description as ship_status
    from
      tracking2 t
      left join sms.enum e on
        t.status = e.enum_id and
        e.entity_name = 'package_status'
  )
  SELECT
    m.id as movement_id, 'MOV-' || m.id as movement, e2.description as status,
    ef.description as from_loc_type,
    'T-' || df.territory || ' - ' || coalesce (sf2.name, sf.name, df.name) as from,
    et.description as to_loc_type,
    'T-' || coalesce (dt.territory, dt2.territory) || ' - ' ||
      coalesce (st3.name, st2.name, st.name, dt.name, dt2.name) as to,
    m.package_count,
    case
      when array_length (t.track_nos, 1) is null then null
      else substring (t.track_nos::varchar, 2, length (t.track_nos::varchar) - 2)
    end as tracking,
    m.pull_by_date, m.deliver_by_date, t.ship_status, t.last_shipment,
    'ORD-' || o.id, o.status::varchar, m.created_date as movement_date
  FROM
    sms.order_header o
    INNER JOIN sms.movement m ON
      m.order_id = o.id and
      m.id >= 824416 and
      m.created_date >= '2014-01-01'
    left join sms.enum ef on
      m.from_location_type = ef.enum_id and
      ef.entity_name = 'location_type'
    left join sms.enum et on
      m.to_location_type = et.enum_id and
      et.entity_name = 'location_type'
    left join sms.enum e2 on
      m.status = e2.enum_id and
      e2.entity_name = 'movement_status'
    left join sms.distributor dt ON
      m.to_distributor_id = dt.id
    left join sms.distributor dt2 on
      m.to_location_type = 2 and  -- distributor
      m.to_location_id = dt2.id
    left join sms.site st on
      m.to_location_type = 1 and  -- site
      m.to_location_id = st.id
    left join sms.sales_associate sat on
      m.to_location_type = 8 and  -- sales associate
      m.to_location_id = sat.id
    left join sms.site st2 on
      sat.site_id = st2.id
    left join sms.account act on
      m.to_location_type = 9 and  -- account
      m.to_location_id = act.id
    left join sms.site st3 on
      act.site_id = st3.id
    join sms.distributor df ON m.distributor_id = df.id
    left join sms.site sf on
      m.from_location_type = 1 and  -- site
      m.from_location_id = sf.id
    left join sms.sales_associate saf on
      m.from_location_type = 8 and  -- sales associate
      m.from_location_id = saf.id
    left join sms.site sf2 on
      saf.site_id = sf2.id
    left join sms.account af on
      m.from_location_type = 9 and  -- account
      m.from_location_id = af.id
    left join sms.site sf3 on
      af.site_id = sf3.id
    left join tracking3 t on
      m.id = t.movement_id
  WHERE
    o.id >= 600000 and
    m.from_location_type = 1 AND 
    m.from_location_id IN (470, 490, 1891)
  order by 1;
  
  GET DIAGNOSTICS rowcount = ROW_COUNT;
  total_count := total_count + rowcount;

  return total_count;
END;
$$
