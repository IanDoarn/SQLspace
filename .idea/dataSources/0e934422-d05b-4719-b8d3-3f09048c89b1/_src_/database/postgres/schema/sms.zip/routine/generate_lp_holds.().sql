CREATE FUNCTION generate_lp_holds () RETURNS integer
	LANGUAGE plpgsql
AS $$

DECLARE
  rowcount integer := 0;
BEGIN

  -- Query returned successfully: 398 rows affected, 2709 ms execution time.
  -- Query returned successfully: 515 rows affected, 1078 ms execution time.
  
  truncate table sms.loaner_pool_holds;

  insert into sms.loaner_pool_holds
  SELECT
    d.territory || ' - ' || d.name AS distributor, p.product_number, p.description, 
    s.quantity_on_hand AS qoh, 
        CASE
            WHEN s.hold_reason = 0 THEN 'No'
            ELSE 'Yes'
        END AS on_hold, 
    h.description AS hold_reason, s.hold_note, f.serial_number AS lot_serial, 
    d.territory, c.surgery_date, current_timestamp - c.surgery_date AS days_since_surgery
  FROM
    sms.stock s
    LEFT JOIN sms.enum lt ON 
      s.location_type = lt.enum_id AND 
      lt.entity_name = 'location_type'
    JOIN sms.product p ON 
      s.product_id = p.id
    JOIN sms.distributor d ON 
      s.distributor_id = d.id
    LEFT JOIN sms.enum e ON 
      s.inventory_type = e.enum_id AND 
      e.entity_name = 'inventory_type'
    JOIN sms.product_serial f ON 
      s.serial_id = f.id AND 
      f.serial_number < 999
    LEFT JOIN sms.enum h ON 
      s.hold_reason = h.enum_id AND 
      h.entity_name = 'hold_reason'
    LEFT JOIN sms.case_table c ON 
      s.container_id = c.id AND 
      s.container_type = 4
  WHERE
    s.inventory_type in (2, 5, 6) AND 
    p.in_loaner_pool = 1 AND 
    h.description != 'AWAITING_QC_CHECK';
  
  return rowcount;
END;
$$
