CREATE VIEW millstone_shipments AS
WITH countries AS (
         SELECT arc.country_nme,
            arc.region_nme,
            arc.area_nme,
            row_number() OVER (PARTITION BY arc.country_nme ORDER BY 1::integer) AS rn
           FROM congl.arc
        UNION ALL
         SELECT 'US'::character varying AS "varchar",
            'AMERICAS'::character varying AS "varchar",
            'AMERICAS'::character varying AS "varchar",
            1
        UNION ALL
         SELECT 'United States'::character varying AS "varchar",
            'AMERICAS'::character varying AS "varchar",
            'AMERICAS'::character varying AS "varchar",
            1
        )
 SELECT ((to_char((l.order_date)::timestamp with time zone, 'YYYY'::text) || '-Q'::text) || to_char((l.order_date)::timestamp with time zone, 'Q'::text)) AS year_qtr,
    l.kit_comp,
    l.kit_lot,
    l.kit,
    l.order_date,
    l.ship_id,
    l.prod_id,
    l.description,
    l.lot_id,
    l.item_qty,
    l.std_cost,
    l.country,
    l.region,
    l.territory,
    l.bus_seg_kit,
    l.kit_description,
    l.millstone_cost,
    'Legacy'::character varying AS source,
    NULL::character varying AS distributor_name,
    (to_char((l.order_date)::timestamp with time zone, 'YYYY_'::text) || date_part('month'::text, l.order_date)) AS month_num,
    date_part('year'::text, l.order_date) AS year_num,
    (0)::bigint AS movement_id,
    'Complete'::character varying AS movement_status
   FROM sms.millstone_legacy_shipping_history l
UNION ALL
 SELECT ((to_char(s.order_date, 'YYYY'::text) || '-Q'::text) || to_char(s.order_date, 'Q'::text)) AS year_qtr,
    im.kit_indic_flg AS kit_comp,
    NULL::character varying AS kit_lot,
    NULL::character varying AS kit,
    s.order_date,
    concat('ORD-', s.order_id, '/', 'MVMT-', s.movement_id) AS ship_id,
    s.prod_id,
    s.description,
    s.lot_id,
    s.quantity AS item_qty,
    im.std_cost_bws_total_amt AS std_cost,
        CASE
            WHEN ((s.site_id = 670) AND ((s.distributor_name)::text = 'LATIN AMERICA'::text)) THEN 'PUERTO RICO'::character varying
            WHEN (((s.distributor_name)::text = 'LATIN AMERICA'::text) AND ((s.country)::text = 'United States'::text)) THEN 'PUERTO RICO'::character varying
            ELSE s.country
        END AS country,
        CASE
            WHEN ((s.country)::text = 'CZECH REPUBLIC'::text) THEN 'EMEA'::character varying
            WHEN ((s.country)::text = 'EL SALVADOR'::text) THEN 'LAT AMER'::character varying
            WHEN ((s.country)::text = 'KINGDOM OF BAHRAIN'::text) THEN 'EMEA'::character varying
            WHEN ((s.country)::text = 'UNITED ARAB EMIRATES'::text) THEN 'EMEA'::character varying
            WHEN ((s.country)::text = 'United States'::text) THEN 'LAT AMER'::character varying
            WHEN ((r.country_nme)::text = 'LATIN AMERICA'::text) THEN 'LAT AMER'::character varying
            WHEN ((r.area_nme)::text = 'ASIA'::text) THEN 'APAC'::character varying
            WHEN ((r.region_nme)::text = 'EUROPE'::text) THEN 'EMEA'::character varying
            WHEN (r.region_nme IS NULL) THEN (split_part((s.distributor_name)::text, ' - '::text, 1))::character varying
            WHEN ((r.region_nme)::text = 'AMERICAS'::text) THEN 'AMER'::character varying
            ELSE r.region_nme
        END AS region,
    s.territory,
    im.business_segment_des AS bus_seg_kit,
    NULL::character varying AS kit_description,
        CASE
            WHEN (s.order_date >= '2014-07-01 00:00:00'::timestamp without time zone) THEN (25 * s.quantity)
            ELSE (15 * s.quantity)
        END AS millstone_cost,
    'SMS'::character varying AS source,
    s.distributor_name,
    (to_char(s.order_date, 'YYYY_'::text) || date_part('month'::text, s.order_date)) AS month_num,
    date_part('year'::text, s.order_date) AS year_num,
    s.movement_id,
    s.movement_status
   FROM ((sms.millstone_shipments_sms s
     LEFT JOIN util.global_item_master im ON (((s.prod_id)::text = (im.prod_id)::text)))
     LEFT JOIN countries r ON (((upper((s.country)::text) = (r.country_nme)::text) AND (r.rn = 1))))
  ORDER BY 5