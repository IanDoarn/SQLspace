CREATE FUNCTION process_fedex_data () RETURNS integer
	LANGUAGE plpgsql
AS $$

DECLARE
  rowcount integer := 0;
  total_count integer := 0;
  
BEGIN

  truncate table stage.sms_fedex_data;

  copy stage.sms_fedex_data from '/apps/external_data/inbound/fedexzsms1.csv' with null as '' csv;
  copy stage.sms_fedex_data from '/apps/external_data/inbound/fedexzsms2.csv' with null as '' csv;
  copy stage.sms_fedex_data from '/apps/external_data/inbound/fedexzsms3.csv' with null as '' csv;
  copy stage.sms_fedex_data from '/apps/external_data/inbound/fedexzsms4.csv' with null as '' csv;

  delete from stage.sms_fedex_data
  where
    sms_package not ilike 'pkg%';

  update stage.sms_fedex_data
  set
    sms_package = regexp_replace (sms_package, '(PKG-\d+)\D.*', E'\\1', 'i')
  where
    sms_package ~* 'PKG-\d+\D';

  insert into sms.fedex_data
  select
    case
      when lower (sms_package) like 'pkg%'
        then cast (replace (replace (upper (s.sms_package), 'PKG', ''), '-', '') as bigint)
        else 0
      end as package_id,
    s.sms_package, s.tracking_number, s.weight, s.freight
  from stage.sms_fedex_data s
  where not exists (
    select null
    from sms.fedex_data f
    where
      s.sms_package = f.sms_package
  );

  GET DIAGNOSTICS rowcount = ROW_COUNT;
  total_count := total_count + rowcount;

  insert into sms.freight_override
  select
    p.id, null, null, min (f.weight), current_timestamp
  from
    sms.package p
    join sms.fedex_data f on
      p.id = f.package_id
  where
    p.shipping_weight != f.weight and
    p.shipping_weight = 0 and
    p.shipped_date >= '2015-05-22' and
    p.id not in (select package_id from sms.freight_override)
  group by
    p.id;

  return total_count;
END;
$$
