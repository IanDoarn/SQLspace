CREATE FUNCTION update_lp_late_history () RETURNS integer
	LANGUAGE plpgsql
AS $$

DECLARE
  rowcount integer := 0;
begin

  truncate table sms.lp_late_items_current;

  insert into sms.lp_late_items_current
  select
    c.name as distributor_name, a.id as case_id, a.surgery_date,
    current_date - a.surgery_date::date as days_since_surgery,
    d.name as account_name, e.code, f.name as procedure_name,
    g.product_number, g.description, c.territory
  from
    sms.case_table a,
    sms.stock b,
    sms.distributor c,
    sms.account d,
    sms.surgeon e,
    sms.procedure_table f,
    sms.product g,
    sms.product_serial h
  where
    a.id = b.container_id and
    a.distributor_id = c.id and
    a.account_id = d.id and
    a.surgeon_id = e.id and
    a.procedure_id = f.id and
    b.product_id = g.id and
    b.serial_id = h.id and
    b.container_type = 4 and -- Loan
    b.inventory_type = 2; -- Loaner Pool

  delete
  from
    sms.lp_late_items_history a
  where exists
  (
    select null
    from sms.lp_late_items_current b
    where
      a.case_num = b.case_num and
      date_trunc ('day', a.surgery_date) = date_trunc ('day', b.surgery_date) and
      a.product = b.product
  );
  
  insert into sms.lp_late_items_history
  select
    a.distributor, a.case_num, a.surgery_date, a.days_since_surgery,
    a.account, a.surgeon, a.procedure_desc, a.product,
    a.product_desc, current_date, a.territory
  from
    sms.lp_late_items_current a;

  return rowcount;
end;
$$
